/*
             Object Oriented Programming 
             <Electricity billing System>
             Group Members:
             1.<Mirza Mobeen> <F20605043>
              2. <Faisal Nawaz> <F20605022>
              3. <Mehmood Ul Haq> <F20605012>
              */

package electricity.billing.system;

import java.sql.*;

public class Conn {

    Connection c;
    Statement s;
    Conn() {
        try {
            c = DriverManager.getConnection("jdbc:mysql:///ebs", "root", "18916600");
            s = c.createStatement();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
